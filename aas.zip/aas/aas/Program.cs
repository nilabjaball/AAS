﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data;

using Microsoft.AnalysisServices;
using Microsoft.AnalysisServices.Tabular;
using Microsoft.AnalysisServices.AdomdClient;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Auth;
using Microsoft.WindowsAzure.Storage.Blob;
// Install the references using package manager 



namespace aas
{
    class Program
    {
        static void Main(string[] args)
        {

            string conn = "Provider=MSOLAP;";
            conn += "Data Source=asazure://westeurope.asazure.windows.net/neelul;";
            conn += "Catalog=adventureworks;";

            string query_String = @"EVALUATE('Customer')";
            string accountName = "testneeldemo";
            string accountKey = "qJEMccOooVX2p2KrBR2ZotkOReTDHlWNj7Znt7ue+w+5h/rV5npBVMNsBZ9BS/dhy2alidIR5qv/UYSls3xaHw==";
            string response = "";
            string sep = ",";


            StorageCredentials creds = new StorageCredentials(accountName, accountKey);
            CloudStorageAccount account = new CloudStorageAccount(creds, useHttps: true);
            CloudBlobClient client = account.CreateCloudBlobClient();
            CloudBlobContainer sampleContainer = client.GetContainerReference("testaas");
            sampleContainer.CreateIfNotExists();
            CloudBlockBlob blob = sampleContainer.GetBlockBlobReference("test.csv");

            AdomdConnection adomd_conn = new AdomdConnection();
            adomd_conn.ConnectionString = conn;
            adomd_conn.Open();
            AdomdCommand cmd = new AdomdCommand(query_String, adomd_conn);
            var line = " ";
            StringBuilder sb = new StringBuilder();
            using (var reader = cmd.ExecuteReader())
            {

                int fields = reader.FieldCount - 1;

                while (reader.Read())
                {

                   
                    for (int i = 0; i <= fields; i++)
                    {
                        if (i != fields)
                        {
                            sep = ",";
                        }
                        else
                        {
                            sep = "";
                        }

                        if (reader[i] == null || reader[i] == DBNull.Value)
                        {
                            line = " " + sep.ToString();
                        }
                        else
                            line = reader[i].ToString() + sep.ToString();

                        Console.Write(line.ToString());
                        sb.Append(line.ToString());

                    }

                }
                    var myByteArray = System.Text.Encoding.UTF8.GetBytes(sb.ToString());
                    var ms = new MemoryStream(myByteArray);
                blob.UploadFromStream(ms);



            }


            

            /* Wait for Key Press */
            Console.ReadKey();
        }
    }
}
